import sys
import os
from pathlib import Path
import shutil


def main(data_root):
    subset_count = 1
    class_to_subset = "1"
    source_dir = data_root + "\\" + class_to_subset
    dest_dir = data_root + "\\" + class_to_subset + "_subset"
    if not os.path.exists(dest_dir):
        os.mkdir(dest_dir)
    counter = 0
    subset_class_other_iter = Path(source_dir).glob("*_other.npy")
    for f in subset_class_other_iter:
        counter = counter + 1
        other_filename = str(f).split("\\")[-1]
        mfcc_filename = "_".join(other_filename.split("_")[:-1]) + "_mfcc.npy"
        shutil.copy(source_dir + "\\" + other_filename, dest_dir + "\\" + other_filename)
        shutil.copy(source_dir + "\\" + mfcc_filename, dest_dir + "\\" + mfcc_filename)
        if counter == subset_count:
            break
    os.rename(source_dir, data_root + "\\" + class_to_subset + "_old")
    os.rename(dest_dir, source_dir)


if __name__ == "__main__":
    # needs one command line argument.
    # 1. root path of data
    main(sys.argv[1])
