#!/bin/bash

# shellcheck disable=SC2044
# shellcheck disable=SC2061
for flac_file in $(find . -name *.flac) ; do
  ffmpeg -hide_banner -i "$flac_file" -ar 16000 "${flac_file%.*}.wav"
  rm -f "$flac_file"
done
