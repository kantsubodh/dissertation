import sys
from pathlib import Path


def main(phoneme_root, out_file):
    out_file = open(out_file, 'w')
    filepath = Path(phoneme_root).glob('*.wav')
    print(filepath)
    for top_dir in filepath:  # os.listdir(phoneme_root):
        extracted_arr = extract_phoneme(top_dir.name)
        out_file.write(top_dir.name + '\t' + extracted_arr[0] + extracted_arr[1] + '\t' + extracted_arr[2]
                       + '\t' + extracted_arr[3] + '\n')

    out_file.close()
    # libri_100-121669-0000_son_ah1_1390_1580


def extract_phoneme(text):
    ret_text = text
    ret_text = ret_text.replace('.wav', '').split('_')
    return ret_text


if __name__ == '__main__':
    # needs two command line argument.
    # 1. root path of LibriSpeech
    # 2. output csv path
    # python script\generate_phoneme_output.py D:\Mtech\Dissertation\train-clean-360\phoneme_slices
    # D:\Mtech\Dissertation\train-clean-360\output_phomene_new.csv
    main(sys.argv[1], sys.argv[2])
    # print(extract_phoneme('libri_100-121669-0000_son_ah1_1390_1580.wav'))
