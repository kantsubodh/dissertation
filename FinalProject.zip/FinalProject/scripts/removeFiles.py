import os
import sys
from pathlib import Path
import csv


def main(phoneme_root,output_path):
    #remove_files(phoneme_root)
    print(read_stop_words())
    remove_stop_words(phoneme_root,output_path)


def remove_files(phoneme_root):
    filepath = Path(phoneme_root).glob('*.npy')
    map_of_files = {}
    print(filepath)
    for top_dir in filepath:  # os.listdir(phoneme_root):
        extracted_arr = extract_phoneme(top_dir.name)
        filename = extracted_arr[0] + "_" + extracted_arr[1] + "_" + extracted_arr[2]
        group = map_of_files.get(filename, [])
        group.append(top_dir.name)
        map_of_files[filename] = group
    # libri_100-121669-0000_son_ah1_1390_1580
    for key in map_of_files:
        if len(map_of_files.get(key)) < 2:
            if os.path.isfile(map_of_files.get(key)[0]):
                os.remove(map_of_files.get(key)[0])
            print(key, len(map_of_files.get(key)), map_of_files.get(key)[0])
            os.remove(phoneme_root + "\\" + map_of_files.get(key)[0])


def read_stop_words():
    with open("D:\\Mtech\\Dissertation\\FinalProject\\feature_extraction\\ignored_word.txt", "r") as data:
        return [d.replace("\n", "") for d in data.readlines()]


def remove_stop_words(phoneme_path,output_path):
    filepath = Path(phoneme_path).glob('*.npy')
    print(filepath)
    stop_word_list = read_stop_words()
    for top_dir in filepath:  # os.listdir(phoneme_root):
        extracted_arr = extract_phoneme(top_dir.name)
        if extracted_arr[1] in stop_word_list:
            print("found the stop word in ", extracted_arr)
            os.replace(phoneme_path + "\\" + top_dir.name, output_path + "\\" + top_dir.name)


def extract_phoneme(text):
    ret_text = text
    ret_text = ret_text.replace('.npy', '').split('_')
    return ret_text


if __name__ == '__main__':
    # needs two command line argument.
    # 1. root path of LibriSpeech
    # 2. output csv path
    # python script\generate_phoneme_output.py D:\Mtech\Dissertation\train-clean-360\phoneme_slices
    # D:\Mtech\Dissertation\train-clean-360\output_phomene_new.csv
    main(sys.argv[1], sys.argv[2])
    # print(extract_phoneme('libri_100-121669-0000_son_ah1_1390_1580.wav'))
