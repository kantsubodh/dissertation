import matplotlib.pyplot as plt
import numpy as np
import librosa.display
from dataset import Dataset

TRAIN_PATH = "D:\\Mtech\\Dissertation\\train-clean-360\\train\\train_data"
TEST_PATH = "D:\\Mtech\\Dissertation\\train-clean-360\\test\\test_data"
mfcc_feat = np.load("D:\\Mtech\\Dissertation\\train-clean-360\\npy\\0\\libri_100-121669-0001_crying_ih0_mfcc.npy")
other_feat = np.load("D:\\Mtech\\Dissertation\\train-clean-360\\npy\\0\\libri_100-121669-0001_crying_ih0_other.npy")
print(mfcc_feat)
print(other_feat)

plt.figure(figsize=(10, 3))
librosa.display.waveshow(mfcc_feat[0])
librosa.display.waveshow(mfcc_feat[1])
librosa.display.waveshow(mfcc_feat[2])
# librosa.display.specshow(mfcc_feat[1])
# plt.colorbar()
# plt.plot(other_feat)

plt.tight_layout()
plt.title('mfcc')
plt.show()
train_dataset = Dataset(root=TRAIN_PATH)
test_dataset = Dataset(root=TEST_PATH)
print(train_dataset.__len__())
print(test_dataset.__len__())

